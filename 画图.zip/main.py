import re


def main():
    selected = []
    ele = []
    num = []
    result = []
    file = open("pointnet_sem_seg_bedroom.log", "r")
    Lines = file.readlines()

    for line in Lines:
        if (
            re.search("---- EPOCH [0-9][0-9][0-9] EVALUATION ----", str(line))
            or re.search("Eval mean loss: [-+]?(?:\d*\.*\d+)", str(line))
            or re.search("Eval accuracy: [-+]?(?:\d*\.*\d+)", str(line))
        ):
            ele.append(line.split("INFO")[1])
            if len(ele) == 3:
                selected.append(ele)
                ele = []
    for i in selected:
        for j in i:
            num.append(re.findall(r"[-+]?\d*\.?\d+|[-+]?\d+", j)[0])
            if len(num) == 3:
                result.append(num)
                num = []
    with open("result.txt", "a") as the_file:
        for i in result:
            the_file.write(f"{i[1]} {i[2]}\n")

    print(result)


main()
