import matplotlib.pyplot as plt
import numpy as np

def draw_curve(filename):
    data=np.loadtxt(filename,dtype=np.float32)
    y1=data[:,0]
    plt.ylim([0, 1.75])
    plt.yticks([0, 0.25, 0.5, 0.75, 1.00, 1.25, 1.50,1.75])
    x1=range(0,50)
    plt.plot(x1,y1,label='Loss',linewidth=1,color='b',marker='o',
             markerfacecolor='blue',markersize=3)
    plt.xlabel('count')
    plt.legend(loc='upper right', fontsize=20)
    y2=data[:,1]
    x2=range(0,50)
    plt.plot(x2,y2,label='Acc',linewidth=1,color='r',marker='o',
             markerfacecolor='blue',markersize=3)
    plt.legend(loc='upper right', fontsize=20)
    plt.show()

def main():
    filename='result.txt'
    draw_curve(filename)
    print('Finish')

if __name__=='__main__':
    main()
